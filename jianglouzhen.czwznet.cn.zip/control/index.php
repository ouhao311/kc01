<?php
// +----------------------------------------------------------------------
// | Name: 首页
// +----------------------------------------------------------------------
// | Version: V1.0 By:sanshui
// +----------------------------------------------------------------------
// | Copyright (c) 2012-2018 http://www.hanett.com All rights reserved.
// +----------------------------------------------------------------------
defined('SSZCMS') or exit('Access Denied');

class indexControl extends PcControl{
	
    public function __construct(){
        parent::__construct(); 
    }
	
	public function indexDo(){

		$lang = Language::getLangContent();
		$title=C('site_name');
		$keywords=C('site_keywords');
		$description=C('site_description');
		//首页banner图
		$banner_list=getAdinfoList(1);
		
		$news = M('article');
		//头条列表
		$toutiao_list	= $news->getList('rec',1);  
		
		//特别推荐
		$banner3_list=getAdinfoList(3); 
		
		//最新20个会员
		$userlist=M('member')->where(array('isdel'=>0,'state'=>1,'isreview'=>1))->limit(20)->order('addtime desc')->select();
		
		
		include T('index');
	}
	  
}