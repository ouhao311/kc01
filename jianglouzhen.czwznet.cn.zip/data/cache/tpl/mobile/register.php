<?php defined('SSZCMS') or exit('Access Denied');?><html class="js mobile no-desktop no-ie ios ios11 weixin-section index-section w-414 gt-240 gt-320 lt-480 lt-640 lt-768 lt-800 lt-1024 lt-1280 lt-1440 lt-1680 lt-1920 portrait no-landscape gradient rgba opacity textshadow multiplebgs boxshadow borderimage borderradius cssreflections csstransforms csstransitions touch retina fontface am-touch cssanimations" id="index-page">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?php echo $title;?></title>
<meta name="keywords" content="<?php if(empty($keywords)) { ?><?php echo C('site_keywords');?><?php } else { ?><?php echo $keywords;?><?php } ?>
" />
<meta name="description" content="<?php if(empty($description)) { ?><?php echo C('site_description');?><?php } else { ?><?php echo $description;?><?php } ?>
" />
<meta name="author" content="<?php echo C('site_name');?>" />  
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-siteapp">
<script type="text/javascript">
//全局变量
var GV = {
ROOT: "/",
WEB_ROOT: "",
JS_ROOT: "/public/wap/js/",
API: "/api/",
IMG_PATH: "/data/upload/",
SIGN: "96f108f0953942ec92c650d7e865d047",
TIMESTAMP: "1595074860",
SITE_NAME: "<?php echo C('site_name');?>",
TMPL: "/public/"
};
</script>
<link rel="stylesheet" href="//at.alicdn.com/t/font_768898_z5pahct8psr.css">
<link href="/public/wap/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="/public/wap/css/amazeui.min.css">
<link rel="stylesheet" href="/public/wap/css/style.css">
<link rel="stylesheet" href="/public/wap/css/weui.min.css">
<link rel="stylesheet" href="/public/wap/css/graceUI.css">
<link rel="stylesheet" href="/public/wap/css/mycss.css">
<link rel="stylesheet" href="/public/wap/css/app.css">
<link rel="stylesheet" href="/public/wap/css/study_index.css">
<!-- F样式 -->
<script src="/public/wap/js/jquery.js"></script>
<script src="/public/wap/js/wind.js"></script>
<link rel="stylesheet" href="/public/wap/css/swiper.css">  
<style type="text/css">
._v-container[data-v-ecaca2b0]{-webkit-tap-highlight-color:rgba(0,0,0,0);width:100%;height:100%;position:absolute;top:0;left:0;overflow:hidden;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-o-user-select:none;user-select:none}._v-container>._v-content[data-v-ecaca2b0]{width:100%;-webkit-transform-origin:left top;-webkit-transform:translateZ(0);-moz-transform-origin:left top;-moz-transform:translateZ(0);-ms-transform-origin:left top;-ms-transform:translateZ(0);-o-transform-origin:left top;-o-transform:translateZ(0);transform-origin:left top;transform:translateZ(0)}._v-container>._v-content>.pull-to-refresh-layer[data-v-ecaca2b0]{width:100%;height:60px;margin-top:-60px;text-align:center;font-size:16px;color:#aaa}._v-container>._v-content>.loading-layer[data-v-ecaca2b0]{width:100%;height:60px;text-align:center;font-size:16px;line-height:60px;color:#aaa;position:relative}._v-container>._v-content>.loading-layer>.no-data-text[data-v-ecaca2b0]{position:absolute;left:0;top:0;width:100%;height:100%;z-index:1}._v-container>._v-content>.loading-layer>.no-data-text[data-v-ecaca2b0],._v-container>._v-content>.loading-layer>.spinner-holder[data-v-ecaca2b0]{opacity:0;transition:opacity .15s linear;-webkit-transition:opacity .15s linear}._v-container>._v-content>.loading-layer>.no-data-text.active[data-v-ecaca2b0],._v-container>._v-content>.loading-layer>.spinner-holder.active[data-v-ecaca2b0]{opacity:1}._v-container>._v-content>.loading-layer .spinner-holder[data-v-ecaca2b0],._v-container>._v-content>.pull-to-refresh-layer .spinner-holder[data-v-ecaca2b0]{text-align:center;-webkit-font-smoothing:antialiased}._v-container>._v-content>.loading-layer .spinner-holder .arrow[data-v-ecaca2b0],._v-container>._v-content>.pull-to-refresh-layer .spinner-holder .arrow[data-v-ecaca2b0]{width:20px;height:20px;margin:8px auto 0;-webkit-transform:translateZ(0) rotate(0deg);transform:translateZ(0) rotate(0deg);transition:transform .2s linear}._v-container>._v-content>.loading-layer .spinner-holder .text[data-v-ecaca2b0],._v-container>._v-content>.pull-to-refresh-layer .spinner-holder .text[data-v-ecaca2b0]{display:block;margin:0 auto;font-size:14px;line-height:20px;color:#aaa}._v-container>._v-content>.loading-layer .spinner-holder .spinner[data-v-ecaca2b0],._v-container>._v-content>.pull-to-refresh-layer .spinner-holder .spinner[data-v-ecaca2b0]{margin-top:14px;width:32px;height:32px;fill:#444;stroke:#69717d}._v-container>._v-content>.pull-to-refresh-layer.active .spinner-holder .arrow[data-v-ecaca2b0]{-webkit-transform:translateZ(0) rotate(180deg);transform:translateZ(0) rotate(180deg)}
</style>
</head>
<body style="">
 
<link rel="stylesheet" type="text/css" href="/public/layui/css/layui.css">
<script src="/public/layui/layui.js"></script>
<div id="xmLogin">
<header class="zyw-header"><a href="javascript:history.go(-1)" class="xmIconfont head-l"></a>
<div class="head-c">
注册
</div>
<a href="/" class="rightTitle xmIconfont"></a></header>
<div class="ht45">
</div>
<div class="grace-body jddw">
<div class="white">
<div class="xmIconfont hyicon">

</div>
</div>
<form id="J_loginMod" class="grace-form marginTop30">
<div class="grace-items">
<div class="grace-label">
<span>账号</span>
</div>
<input type="text" name="username" placeholder="手机号/邮箱" class="input">
</div>
<div class="grace-items">
<div class="grace-label">
<span>密码</span>
</div>
<input type="password" name="regPassword" placeholder="请输入您的密码" class="input">
</div> 
<div class="grace-items">
<div class="grace-label">
<span>确认密码</span>
</div>
<input type="password" name="confirmPassword" placeholder="请确认您的密码" class="input">
</div> 
<div class="grace-items">
<div class="grace-label">
<span>姓名</span>
</div>
<input type="text" name="truename" placeholder="您的真实姓名" class="input">
</div>
<div class="grace-items">
<div class="grace-label">
<span>职能部门</span>
</div>
<?php echo getNotSelectq('department','');?>
</div>
<div class="grace-button grace-border-radius"   onclick="register()">
注册
</div>
<div class="am-sans-serif"> 
<a href="<?php echo url('login','index');?>" style="margin-top: 10px; float: right; font-size: 14px;">返回登录</a>
</div>
</form>
<div class="dwdbXm"> 
<div class="txt">
<?php echo C('site_copyright');?>
</div>
</div>
</div> 
</div> 
<!--主体内容 结束-->
<script>
layui.use(['layer','form'], function(){
    var $ = layui.jquery, layer = layui.layer, form = layui.form;
});
//获取用户名和密码并判断不能为空
function register(){
    var data= $("form#J_loginMod").serialize(); 
    $.ajax({
        type: "POST",
        url: "<?php echo url('register','preSave');?>",
        data: data,
        dataType: 'json',
        success: function(msg){
            if(msg.result==false){
                layer.alert(msg.message.error, {
                    time: 3000, //3s后自动关闭
                    btn: ['确定']
                });
            }else{
layer.msg(msg.message.error, { 
time: 2000
}, function(){ 
window.location.href = "<?php echo url('member');?>";
}); 
            }
        }
    });
}
//发送验证码
$(".get_code").click(function() {
var mobile = $("#mobile").val();
if (mobile == "") {
layer.msg("手机号不能为空!");
return false;
}
if ($('.get_code').attr("disabled")) {
return false;
}else {
$.post('/index.php?url=ajax&do=sendCode&mobile=' + $("#mobile").val(), function(data) {
data = $.parseJSON(data);
if (data.err == 1) {
globalFunc.time();
} else {
layer.msg(data.msg);
}
});
}
});
var second = 60;
var globalFunc = {
time: function() { 
if (second == 0) {
$(".get_code").removeAttr("disabled");
$(".get_code").val("输入验证码");
$(".get_code").css({
background: '#EA5514',
borderColor: '#EA5514',
color: '#fff'
}); 
second = 60; 
} else {
$(".get_code").attr("disabled", 'disabled');
$(".get_code").val(second + "秒后重新获取");
$(".get_code").css({
background: '#333',
borderColor: '#333',
color: '#f1f1f1'
}); 
second--;
setTimeout(function() {
globalFunc.time()
}, 1000)
}
}
};
</script>
<?php include T('footer');?>