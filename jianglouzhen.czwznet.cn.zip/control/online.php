<?php
// +----------------------------------------------------------------------
// | Name: 线上解疑
// +----------------------------------------------------------------------
// | Version: V1.0 By:sanshui
// +----------------------------------------------------------------------
defined('SSZCMS') or exit('Access Denied'); 
class onlineControl extends PcControl{

    public function __construct(){
        parent::__construct(); 
    }

    // 首页部分
    public function indexDo(){
		$lang = Language::getLangContent();
		$keyword=$_GET['keywords']; 
		$title="线上解疑平台";
		$keywords=C('site_keywords');
		$description=C('site_description');
		//获取列表
		$condition=array();
		$condition['isreview']	= 1;
		$condition['isdel']	= 0; 
		
		$online = M('online');
		$page	= new Page();
		$page->setEachNum(20);
		$page->setStyle('5');
		$list	= $online->getonlineList($condition,$page);
		$show_page=$page->show();  
		
		$banner_list=getAdinfoList(2);
		
		include T('online');
        
    } 
	
	// 提问
    public function addDo(){
		$lang = Language::getLangContent();
		$mid=$_SESSION['member_id'];
		if(empty($mid)){
			$mid=0;
		}
        $title='解疑平台提问'; 
		if (chksubmit()){
			$data = array(); 
			
			$data['title']      = trim($_POST['title']);  
			$data['intro']      = trim($_POST['intro']);  
			$data['addtime']  = time();  
			$data['ip']       = getIp(); 
			$data['releaseid']      =  $mid;
			 
			$result = M('online_list')->insert($data);/* echo M('online_list')->getLastSql(); */
			if ($result){
				echo '<link rel="stylesheet" type="text/css" href="/public/layui/css/layui.css">';
				echo '<script src="/public/layui/layui.all.js"></script>';
				echo "<script>
					layer.msg('提交成功，请耐心等待回复！', { 
						time: 2000
					}, function(){
						window.location.href='/index.php?url=online';
					});  
					</script>";
				exit();
			}else {
				echo '<link rel="stylesheet" type="text/css" href="/public/layui/css/layui.css">';
				echo '<script src="/public/layui/layui.all.js"></script>';
				echo "<script>
					layer.msg('提交失败！', { 
						time: 2000
					}, function(){
						window.history.back(-1);
					});  
					</script>";
				exit();
			}
		}
		$banner_list=getAdinfoList(2);
		include T('online_add');
    } 
	
	
}