<?php
// +----------------------------------------------------------------------
// | Name: 积分统计
// +----------------------------------------------------------------------
// | Version: V1.0 By:sanshui
// +----------------------------------------------------------------------
defined('SSZCMS') or exit('Access Denied'); 
class integralControl extends PcControl{

    public function __construct(){
        parent::__construct(); 
    }

    // 首页部分
    public function indexDo(){
		$lang = Language::getLangContent();
		$title="积分统计";
		$keywords=$classinfo['seo_keywords'];
		$description=$classinfo['seo_description'];
		
		$userlist=M('member')->where(array('isdel'=>0,'state'=>1,'isreview'=>1))->order('integral desc')->select(); 
		
		include T('integral');
        
    }  
 
	
}