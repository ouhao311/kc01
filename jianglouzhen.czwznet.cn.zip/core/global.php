<?php
// +----------------------------------------------------------------------
// | Name: SSZCMS 入口文件
// +----------------------------------------------------------------------
// | Version: V1.0 By:Yutou
// +----------------------------------------------------------------------
// | Copyright (c) 2012-2018 http://www.sanshuizhou.com All rights reserved.
// +----------------------------------------------------------------------
error_reporting(E_ALL & ~E_NOTICE);
//注册常量
define('SSZCMS',true);
define('DS','/');
define('HX_CORE',str_replace('\\','/',dirname(__FILE__)));
define('HX_ROOT',HX_CORE.'/../');
define('HX_DATA',HX_ROOT.'data');
define("HX_UPLOAD", HX_ROOT . "data/upload");
define("HX_EXT", HX_ROOT . "data/ext");
define('DIR_ADMIN','manage');
define('DIR_UPLOAD','data/upload');
define('DIR_TPL', 'default');
define('DIR_TPL_MOBILE', 'mobile');
define('DIR_PC', 'pc');
define('DIR_WAP', 'wap');
define('SITE_URL', 'http://'.$_SERVER['HTTP_HOST']);
define('EXT_URL', 'http://'.$_SERVER['HTTP_HOST'].DS.'data/ext');
define('ADMIN_URL', SITE_URL.DS.DIR_ADMIN);
define('BASE_SITE_URL', SITE_URL);
define('UPLOAD_SITE_URL',SITE_URL.DS.DIR_UPLOAD);

define('MEMBER_SITE_URL', SITE_URL.DS.'member');
define('LOGIN_SITE_URL',MEMBER_SITE_URL);
define('MOBILE_SITE_URL', SITE_URL.DS.'wap');


define('StartTime',microtime(true));
define('TIMESTAMP',time());

define('ATTACH_PATH','system');
define('ATTACH_COMMON','system/common');
define('ATTACH_AVATAR','avatar');
define('ATTACH_EDITOR','system/editor');
define('ATTACH_LOGIN','system/login');
define('ATTACH_ADMIN_AVATAR','admin/avatar');
define('ATTACH_PRINT','system/print');
define('ATTACH_ARTICLE','article');
define('ATTACH_ADV','adv');
define('ATTACH_CLASS','class');
define('ATTACH_GOODS','goods/thumb');
define('ATTACH_QRCODE','goods/qrcode');

/**
 * 商品图片
 */
define('GOODS_IMAGES_WIDTH', '60,240,640,1280');
define('GOODS_IMAGES_HEIGHT', '60,240,640,1280');
define('GOODS_IMAGES_EXT', '_60,_240,_640,_1280');





//初始化

if (!@include(HX_DATA.'/config/config.ini.php')) exit('config.ini.php isn\'t exists!');
global $cfg;


define('URL_MODEL',$cfg['url_model']);
define(SUBDOMAIN_SUFFIX, $cfg['subdomain_suffix']);

define('CHARSET',$cfg['db'][1]['dbcharset']);
define('DBDRIVER',$cfg['dbdriver']);
define('SESSION_EXPIRE',$cfg['session_expire']);
define('LANG_TYPE',$cfg['lang_type']);
define('COOKIE_PRE',$cfg['cookie_pre']);

define('DBPRE',$cfg['tablepre']);
define('DBNAME',$cfg['db'][1]['dbname']);

$_GET['url'] = is_string($_GET['url']) ? strtolower($_GET['url']) : (is_string($_POST['url']) ? strtolower($_POST['url']) : null);
$_GET['do'] = is_string($_GET['do']) ? strtolower($_GET['do']) : (is_string($_POST['do']) ? strtolower($_POST['do']) : null);

if (empty($_GET['url'])){
    require_once(HX_CORE.'/lib/route.php');
    new Route($cfg);
}
//统一ACTION
$_GET['url'] = preg_match('/^[\w]+$/i',$_GET['url']) ? $_GET['url'] : 'index';
$_GET['do'] = preg_match('/^[\w]+$/i',$_GET['do']) ? $_GET['do'] : 'index';

//对GET POST接收内容进行过滤,$ignore内的下标不被过滤
$ignore = array('article_content');

if (!class_exists('Security')) require(HX_CORE.'/lib/security.php');
$_GET = !empty($_GET) ? Security::getAddslashesForInput($_GET,$ignore) : array();
$_POST = !empty($_POST) ? Security::getAddslashesForInput($_POST,$ignore) : array();
$_REQUEST = !empty($_REQUEST) ? Security::getAddslashesForInput($_REQUEST,$ignore) : array();
$_SERVER = !empty($_SERVER) ? Security::getAddSlashes($_SERVER) : array();


if ($_POST || $_GET || $_COOKIE)
{
    extract($_POST,EXTR_SKIP);
	extract($_GET,EXTR_SKIP);
	extract($_COOKIE,EXTR_SKIP);
}



//启用ZIP压缩
if ($cfg['gzip'] == 1 && function_exists('ob_gzhandler') && $_GET['inajax'] != 1){
	ob_start('ob_gzhandler');
}else {
	ob_start();
}

require_once(HX_CORE.'/lib/queue.php');
require_once(HX_CORE.'/fun/common.php');
require_once(HX_CORE.'/fun/function.php');
require_once(HX_CORE.'/lib/base.php');
require_once(HX_CORE.'/fun/pdo.php');





if(function_exists('spl_autoload_register')) {
	spl_autoload_register(array('Base', 'autoload'));
} else {
	function __autoload($class) {
		return Base::autoload($class);
	}
}
