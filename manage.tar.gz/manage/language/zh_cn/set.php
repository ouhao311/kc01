<?php
defined('SSZCMS') or exit('Access Denied');
/**
 * 设置 语言包
 */
$lang['seo_set_insert_tips'] 		= '可用的代码，点击插入';